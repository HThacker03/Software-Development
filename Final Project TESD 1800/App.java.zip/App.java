package Demo;
import javafx.animation.KeyFrame;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import javafx.stage.Stage;


public class App extends Application {
   public static void main(String[] args) {
       launch(args);
   }
  boolean isPlaying = true;
  Integer score = 0;
  Integer numberValue = 0;
   @Override
   public void start(Stage primaryStage) {
       BorderPane pane = new BorderPane();
       StackPane sPane = new StackPane();
       pane.setCenter(sPane);

       HBox paneForText = new HBox(20);
       Text text1 = new Text("Your Score: ");
       Label number = new Label("0");
       number.setFont(Font.font("Courier", 20));
       text1.setFont(Font.font("Courier", 20));
       paneForText.getChildren().addAll(text1,number);
       pane.setTop(paneForText);

       Rectangle square = new Rectangle(170, 100, 100, 100);
       square.setArcWidth(15);
       square.setArcHeight(25);
       square.setStroke(Color.BLACK);
       square.setFill(Color.WHITE);


       sPane.getChildren().add(square);
       Label label = new Label("6");
       label.setFont(Font.font("Times New Roman", 50));
       sPane.getChildren().add(label);
       label.setTextFill(Color.BLACK);

      RotateTransition rt = new RotateTransition(Duration.millis(2000), square);
      rt.setByAngle(360);
      rt.setCycleCount(Timeline.INDEFINITE);
      rt.setAutoReverse(false);
      rt.play();
      
      
      
       //create roll action
        EventHandler<ActionEvent> eventHandler = e -> {
            numberValue = (int)((Math.random() * 6) + 1);
            label.setText(Integer.toString(numberValue));
        };

    Timeline animation = new Timeline(new KeyFrame(Duration.millis(75), eventHandler));
    animation.setCycleCount(Timeline.INDEFINITE);

    
    animation.play();

    square.setOnMouseClicked(e -> {
        if (isPlaying == true) { 
            score += Integer.parseInt(label.getText());
            number.setText(Integer.toString(score));
            animation.pause();
            rt.pause();
            isPlaying = false;
        }
        else {
            animation.play();
            rt.play();
            isPlaying = true;   
        }
    });


       //Make color buttons
       HBox paneForRadioButtons = new HBox(20);
      paneForRadioButtons.setPadding(new Insets(5, 5, 5, 5));
      paneForRadioButtons.setStyle("-fx-border-width: 2px; -fx-border-color: green");




      RadioButton rbRed = new RadioButton("Barbarian");
      RadioButton rbYellow = new RadioButton("Druid");
      RadioButton rbBlack = new RadioButton("Bard");
      RadioButton rbOrange = new RadioButton("Wizard");
      RadioButton rbGreen = new RadioButton("Fighter");
    
      paneForRadioButtons.getChildren().addAll(rbRed, rbYellow, rbBlack, rbOrange, rbGreen);
      pane.setBottom(paneForRadioButtons);




      ToggleGroup group = new ToggleGroup();
      rbRed.setToggleGroup(group);
      rbYellow.setToggleGroup(group);
      rbBlack.setToggleGroup(group);
      rbOrange.setToggleGroup(group);
      rbGreen.setToggleGroup(group);


      //creating my colors
      Color color = new Color(0.58, 0.16, 0.21, 1);
      Color color2 = new Color(0.62, 0.24, 0.56, 0.6);
      Color color3 = new Color(0.13, 0.44, 0.21, 0.82);
      Color color4 = new Color(0.2, 0.5, 0.75, 0.73);
      Color color5 = new Color(1, 0.46, 0, 0.7);






      rbRed.setOnAction (e -> {
          if (rbRed.isSelected()) {
              square.setFill(color);
          }
      });




      rbBlack.setOnAction (e -> {
          if (rbBlack.isSelected()) {
              square.setFill(color2);
          }
      });




      rbYellow.setOnAction (e -> {
          if (rbYellow.isSelected()) {
              square.setFill(color3);
          }
      });




      rbOrange.setOnAction (e -> {
          if (rbOrange.isSelected()) {
              square.setFill(color4);
          }
      });




      rbGreen.setOnAction (e -> {
          if (rbGreen.isSelected()) {
              square.setFill(color5);
          }
      });






  


       Scene scene = new Scene(pane, 425, 300);
       primaryStage.setTitle("Roll!");
       primaryStage.setScene(scene);
       primaryStage.show();
   }
}
