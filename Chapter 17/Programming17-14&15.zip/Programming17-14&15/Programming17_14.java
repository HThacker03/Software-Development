import java.util.Scanner;
import java.io.*;

public class Programming17_14 {
	public static void main(String[] args) throws IOException{
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a file to encrypt: ");
		File inputFile = new File(input.nextLine());
		System.out.print("Enter the output file: ");
		File outputFile = new File(input.nextLine());
		
		try (
			BufferedInputStream in = new BufferedInputStream(new FileInputStream(inputFile));
			BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outputFile));
		) {
			int value;
			while((value = in.read()) != -1) {
				out.write(value + 5);
			}
		}
	}
}