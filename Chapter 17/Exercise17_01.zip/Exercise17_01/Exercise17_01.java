import java.io.*;
public class Exercise17_01 {
	public static void main(String[] args) throws java.io.IOException {
		java.io.File file = new java.io.File("Exercise17_01.txt");
		PrintWriter output = new PrintWriter("Exercise17_01.txt");
		
		for(int i = 0; i < 100; i++){
			int j = (int)(Math.random() * 100);
			output.print(j + " ");
		}
		
		output.close();
	}
}