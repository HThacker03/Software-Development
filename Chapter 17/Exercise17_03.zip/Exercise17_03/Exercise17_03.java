import java.io.*;
public class Exercise17_03 {
	public static void main(String[] args) throws IOException{
		File file = new File("Exercise17_03.dat");
		try (
			FileOutputStream output = new FileOutputStream(file);
		) {
			for(int i = 0; i < 100; i++){
				int j = (int)(Math.random() * 100);
				output.write(j);
		}
		
		try (
			FileInputStream input = new FileInputStream(file);
		) {
			int value;
			int sum = 0;
			while ((value = input.read()) != -1)
			sum += value;
			System.out.print(sum);
		}
			
	}
}
}